﻿using SolicitudesApp.Domain.Entidades;

namespace SolicitudesApp.Application.Solicitudes
{
    public class SolicitudService// : ISolicitudService
    {
     /*   private static readonly List<Solicitud> _datos =
        [
            new() { Id = 1, Motivo = "Compra de laptops", Monto = 4850.75m },
            new() { Id = 2, Motivo = "Viaje a provincia", Monto = 820m }
        ];

        private static SolicitudDto Mapear(Solicitud s) 
            => new(s.Id, s.Motivo, s.Monto, s.Estado.ToString());

        public Task<IEnumerable<SolicitudDto>> ListarAsync()
         => Task.FromResult( _datos.Select(Mapear) );

        public Task<SolicitudDto> CrearAsync(CrearSolicitudDto dto)
        {
            var entidad = new Solicitud
            {
                Id = _datos.Count == 0 ? 1 : _datos.Max(s => s.Id) + 1,
                Motivo = dto.Motivo,
                Monto = dto.Monto              
            };
            _datos.Add(entidad);
            return Task.FromResult( Mapear(entidad) );
        }

        

        public Task<SolicitudDto?> ObtenerAsync(int id)
        {
            var e = _datos.FirstOrDefault( s => s.Id == id);
            return Task.FromResult(e is null ? null : Mapear(e));
        }*/
    }
}
