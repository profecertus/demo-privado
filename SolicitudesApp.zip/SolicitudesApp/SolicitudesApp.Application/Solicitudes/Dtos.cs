﻿namespace SolicitudesApp.Application.Solicitudes
{
    public record CrearSolicitudDto(string Motivo, decimal Monto);

    public record SolicitudDto(int Id, string Motivo, decimal Monto, string Estado);

    public interface ISolicitudService
    {
        Task<IEnumerable<SolicitudDto>> ListarAsync();
        Task<SolicitudDto?> ObtenerAsync(int id);
        Task<SolicitudDto> CrearAsync(CrearSolicitudDto dto);
    }
    internal class Dtos
    {
    }
}
