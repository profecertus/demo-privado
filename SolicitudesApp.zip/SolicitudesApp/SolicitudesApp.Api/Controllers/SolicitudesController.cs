﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.JSInterop.Infrastructure;
using SolicitudesApp.Application.Solicitudes;

namespace SolicitudesApp.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class SolicitudesController : ControllerBase
    {
        private readonly ISolicitudService _srv;

        public SolicitudesController(ISolicitudService srv) => _srv = srv;

        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> Listar() => Ok(await _srv.ListarAsync());

        [HttpGet("{id:int}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> Obtener(int id)
        {
            var dto = await _srv.ObtenerAsync(id);
            return dto is null ? NotFound() : Ok(dto);
        }

        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> Crear(CrearSolicitudDto dto)
        {
            if (dto.Monto <= 0)
            {
                return BadRequest("El monto debe ser mayor a cero");
            }
            var creada = await _srv.CrearAsync(dto);
            return CreatedAtAction(nameof(Obtener), new { id = creada.Id }, creada);
        }


    }
}
