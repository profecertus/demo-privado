using SolicitudesApp.Domain.Entidades;

var solicitante = new Usuario { Id = 1, Nombre = "Ana Torres", Correo = "ana@empresa.com" };
var solicitud = new Solicitud
{
    Id = 1,
    Motivo = "Equipamiento del area de TI",
    SolicitanteId = solicitante.Id,
    Solicitante = solicitante,
    FechaRequerida = DateOnly.FromDateTime(DateTime.Today.AddDays(15)),
    CreadoPor = solicitante.Correo
};
solicitud.Detalles.Add(new SolicitudDetalle
{
    Concepto = "Laptop",
    Cantidad = 3,
    PrecioUnitario = 3200m
});
solicitud.Detalles.Add(new SolicitudDetalle
{
    Concepto = "Monitor",
    Cantidad = 3,
    PrecioUnitario = 750m
});
solicitud.Detalles.Add(new SolicitudDetalle
{
    Concepto = "Teclado",
    Cantidad = 3,
    PrecioUnitario = 120m
});
solicitud.RecalcularTotal();
Console.WriteLine($"Solicitante : {solicitud.Solicitante?.Nombre}");
Console.WriteLine($"Motivo : {solicitud.Motivo}");
Console.WriteLine($"Lineas : {solicitud.Detalles.Count}");
Console.WriteLine($"Monto total : {solicitud.MontoTotal:N2}");
Console.WriteLine($"Estado : {solicitud.Estado}");
foreach (var d in solicitud.Detalles)
    Console.WriteLine($" {d.Concepto,-10} {d.Cantidad} x " +
    $"{d.PrecioUnitario:N2} = {d.Importe:N2}");