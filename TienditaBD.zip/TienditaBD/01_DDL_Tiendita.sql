-- ============================================================================
-- SCRIPT DDL: CREACIÓN DE BASE DE DATOS Y TABLAS - SISTEMA TIENDITA
-- Entorno objetivo: Microsoft SQL Server 2019 / 2022 / Express / LocalDB (Windows)
-- ============================================================================

USE master;
GO

-- Crear la base de datos si no existe
IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = N'TienditaDB')
BEGIN
    CREATE DATABASE TienditaDB
    COLLATE Modern_Spanish_CI_AS;
END
GO

USE TienditaDB;
GO

-- Eliminar tablas si ya existen (en orden inverso de dependencias FK)
IF OBJECT_ID(N'dbo.DetalleVentas', N'U') IS NOT NULL DROP TABLE dbo.DetalleVentas;
IF OBJECT_ID(N'dbo.Ventas', N'U') IS NOT NULL DROP TABLE dbo.Ventas;
IF OBJECT_ID(N'dbo.Productos', N'U') IS NOT NULL DROP TABLE dbo.Productos;
IF OBJECT_ID(N'dbo.Proveedores', N'U') IS NOT NULL DROP TABLE dbo.Proveedores;
IF OBJECT_ID(N'dbo.Categorias', N'U') IS NOT NULL DROP TABLE dbo.Categorias;
GO

-- ============================================================================
-- 1. TABLA: Categorias
-- Clasificación de los productos de la tienda (Bebidas, Lácteos, Snacks, etc.)
-- ============================================================================
CREATE TABLE dbo.Categorias (
    CategoriaId   INT IDENTITY(1,1) NOT NULL,
    Nombre        NVARCHAR(50)      NOT NULL,
    Descripcion   NVARCHAR(250)     NULL,
    Activo        BIT               NOT NULL CONSTRAINT DF_Categorias_Activo DEFAULT (1),

    CONSTRAINT PK_Categorias PRIMARY KEY CLUSTERED (CategoriaId),
    CONSTRAINT UQ_Categorias_Nombre UNIQUE (Nombre)
);
GO

-- ============================================================================
-- 2. TABLA: Proveedores
-- Empresas o distribuidores que abastecen a la tiendita
-- ============================================================================
CREATE TABLE dbo.Proveedores (
    ProveedorId   INT IDENTITY(1,1) NOT NULL,
    Ruc           NVARCHAR(11)      NOT NULL,
    RazonSocial   NVARCHAR(100)     NOT NULL,
    Telefono      NVARCHAR(20)      NULL,
    Email         NVARCHAR(100)     NULL,
    Direccion     NVARCHAR(150)     NULL,
    Activo        BIT               NOT NULL CONSTRAINT DF_Proveedores_Activo DEFAULT (1),

    CONSTRAINT PK_Proveedores PRIMARY KEY CLUSTERED (ProveedorId),
    CONSTRAINT UQ_Proveedores_Ruc UNIQUE (Ruc)
);
GO

-- ============================================================================
-- 3. TABLA: Productos
-- Artículos comercializados en la tienda
-- ============================================================================
CREATE TABLE dbo.Productos (
    ProductoId     INT IDENTITY(1,1) NOT NULL,
    CodigoBarras   NVARCHAR(30)      NOT NULL,
    Nombre         NVARCHAR(100)     NOT NULL,
    CategoriaId    INT               NOT NULL,
    ProveedorId    INT               NOT NULL,
    PrecioCompra   DECIMAL(10,2)     NOT NULL,
    PrecioVenta    DECIMAL(10,2)     NOT NULL,
    Stock          INT               NOT NULL CONSTRAINT DF_Productos_Stock DEFAULT (0),
    FechaRegistro  DATETIME2(7)      NOT NULL CONSTRAINT DF_Productos_FechaRegistro DEFAULT (GETDATE()),
    Activo         BIT               NOT NULL CONSTRAINT DF_Productos_Activo DEFAULT (1),

    CONSTRAINT PK_Productos PRIMARY KEY CLUSTERED (ProductoId),
    CONSTRAINT UQ_Productos_CodigoBarras UNIQUE (CodigoBarras),
    CONSTRAINT FK_Productos_Categorias FOREIGN KEY (CategoriaId) 
        REFERENCES dbo.Categorias (CategoriaId),
    CONSTRAINT FK_Productos_Proveedores FOREIGN KEY (ProveedorId) 
        REFERENCES dbo.Proveedores (ProveedorId),
    CONSTRAINT CK_Productos_PrecioCompra CHECK (PrecioCompra >= 0),
    CONSTRAINT CK_Productos_PrecioVenta CHECK (PrecioVenta >= 0),
    CONSTRAINT CK_Productos_Stock CHECK (Stock >= 0)
);
GO

-- Índice para acelerar búsquedas por categoría y proveedor
CREATE NONCLUSTERED INDEX IX_Productos_CategoriaId ON dbo.Productos (CategoriaId);
CREATE NONCLUSTERED INDEX IX_Productos_ProveedorId ON dbo.Productos (ProveedorId);
GO

-- ============================================================================
-- 4. TABLA: Ventas
-- Cabecera de transacciones comerciales de la tienda
-- ============================================================================
CREATE TABLE dbo.Ventas (
    VentaId        INT IDENTITY(1,1) NOT NULL,
    NumeroBoleta   NVARCHAR(20)      NOT NULL,
    FechaVenta     DATETIME2(7)      NOT NULL CONSTRAINT DF_Ventas_FechaVenta DEFAULT (GETDATE()),
    ClienteNombre  NVARCHAR(100)     NOT NULL CONSTRAINT DF_Ventas_ClienteNombre DEFAULT ('Público General'),
    MetodoPago     NVARCHAR(30)      NOT NULL CONSTRAINT DF_Ventas_MetodoPago DEFAULT ('Efectivo'),
    Total          DECIMAL(10,2)     NOT NULL CONSTRAINT DF_Ventas_Total DEFAULT (0.00),
    Estado         NVARCHAR(20)      NOT NULL CONSTRAINT DF_Ventas_Estado DEFAULT ('Completada'),

    CONSTRAINT PK_Ventas PRIMARY KEY CLUSTERED (VentaId),
    CONSTRAINT UQ_Ventas_NumeroBoleta UNIQUE (NumeroBoleta),
    CONSTRAINT CK_Ventas_Total CHECK (Total >= 0)
);
GO

CREATE NONCLUSTERED INDEX IX_Ventas_FechaVenta ON dbo.Ventas (FechaVenta DESC);
GO

-- ============================================================================
-- 5. TABLA: DetalleVentas
-- Ítems individuales vendidos en cada comprobante
-- ============================================================================
CREATE TABLE dbo.DetalleVentas (
    DetalleId      INT IDENTITY(1,1) NOT NULL,
    VentaId        INT               NOT NULL,
    ProductoId     INT               NOT NULL,
    Cantidad       INT               NOT NULL,
    PrecioUnitario DECIMAL(10,2)     NOT NULL,
    Subtotal       DECIMAL(10,2)     NOT NULL,

    CONSTRAINT PK_DetalleVentas PRIMARY KEY CLUSTERED (DetalleId),
    CONSTRAINT FK_DetalleVentas_Ventas FOREIGN KEY (VentaId) 
        REFERENCES dbo.Ventas (VentaId) ON DELETE CASCADE,
    CONSTRAINT FK_DetalleVentas_Productos FOREIGN KEY (ProductoId) 
        REFERENCES dbo.Productos (ProductoId),
    CONSTRAINT CK_DetalleVentas_Cantidad CHECK (Cantidad > 0),
    CONSTRAINT CK_DetalleVentas_PrecioUnitario CHECK (PrecioUnitario >= 0),
    CONSTRAINT CK_DetalleVentas_Subtotal CHECK (Subtotal >= 0)
);
GO

CREATE NONCLUSTERED INDEX IX_DetalleVentas_VentaId ON dbo.DetalleVentas (VentaId);
CREATE NONCLUSTERED INDEX IX_DetalleVentas_ProductoId ON dbo.DetalleVentas (ProductoId);
GO
