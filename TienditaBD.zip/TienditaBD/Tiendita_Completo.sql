-- ============================================================================
-- SCRIPT COMPLETO: DDL + DML - SISTEMA TIENDITA
-- Entorno: Microsoft SQL Server (Windows - SSMS / sqlcmd / Azure Data Studio)
-- Base de datos: TienditaDB
-- ============================================================================

USE master;
GO

IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = N'TienditaDB')
BEGIN
    CREATE DATABASE TienditaDB COLLATE Modern_Spanish_CI_AS;
END
GO

USE TienditaDB;
GO

-- 1. ELIMINAR TABLAS PREVIAS (ORDEN INVERSO DE FKs)
IF OBJECT_ID(N'dbo.DetalleVentas', N'U') IS NOT NULL DROP TABLE dbo.DetalleVentas;
IF OBJECT_ID(N'dbo.Ventas', N'U') IS NOT NULL DROP TABLE dbo.Ventas;
IF OBJECT_ID(N'dbo.Productos', N'U') IS NOT NULL DROP TABLE dbo.Productos;
IF OBJECT_ID(N'dbo.Proveedores', N'U') IS NOT NULL DROP TABLE dbo.Proveedores;
IF OBJECT_ID(N'dbo.Categorias', N'U') IS NOT NULL DROP TABLE dbo.Categorias;
GO

-- 2. DDL - CREACIÓN DE TABLAS
CREATE TABLE dbo.Categorias (
    CategoriaId   INT IDENTITY(1,1) NOT NULL,
    Nombre        NVARCHAR(50)      NOT NULL,
    Descripcion   NVARCHAR(250)     NULL,
    Activo        BIT               NOT NULL CONSTRAINT DF_Categorias_Activo DEFAULT (1),
    CONSTRAINT PK_Categorias PRIMARY KEY CLUSTERED (CategoriaId),
    CONSTRAINT UQ_Categorias_Nombre UNIQUE (Nombre)
);
GO

CREATE TABLE dbo.Proveedores (
    ProveedorId   INT IDENTITY(1,1) NOT NULL,
    Ruc           NVARCHAR(11)      NOT NULL,
    RazonSocial   NVARCHAR(100)     NOT NULL,
    Telefono      NVARCHAR(20)      NULL,
    Email         NVARCHAR(100)     NULL,
    Direccion     NVARCHAR(150)     NULL,
    Activo        BIT               NOT NULL CONSTRAINT DF_Proveedores_Activo DEFAULT (1),
    CONSTRAINT PK_Proveedores PRIMARY KEY CLUSTERED (ProveedorId),
    CONSTRAINT UQ_Proveedores_Ruc UNIQUE (Ruc)
);
GO

CREATE TABLE dbo.Productos (
    ProductoId     INT IDENTITY(1,1) NOT NULL,
    CodigoBarras   NVARCHAR(30)      NOT NULL,
    Nombre         NVARCHAR(100)     NOT NULL,
    CategoriaId    INT               NOT NULL,
    ProveedorId    INT               NOT NULL,
    PrecioCompra   DECIMAL(10,2)     NOT NULL,
    PrecioVenta    DECIMAL(10,2)     NOT NULL,
    Stock          INT               NOT NULL CONSTRAINT DF_Productos_Stock DEFAULT (0),
    FechaRegistro  DATETIME2(7)      NOT NULL CONSTRAINT DF_Productos_FechaRegistro DEFAULT (GETDATE()),
    Activo         BIT               NOT NULL CONSTRAINT DF_Productos_Activo DEFAULT (1),
    CONSTRAINT PK_Productos PRIMARY KEY CLUSTERED (ProductoId),
    CONSTRAINT UQ_Productos_CodigoBarras UNIQUE (CodigoBarras),
    CONSTRAINT FK_Productos_Categorias FOREIGN KEY (CategoriaId) REFERENCES dbo.Categorias (CategoriaId),
    CONSTRAINT FK_Productos_Proveedores FOREIGN KEY (ProveedorId) REFERENCES dbo.Proveedores (ProveedorId),
    CONSTRAINT CK_Productos_PrecioCompra CHECK (PrecioCompra >= 0),
    CONSTRAINT CK_Productos_PrecioVenta CHECK (PrecioVenta >= 0),
    CONSTRAINT CK_Productos_Stock CHECK (Stock >= 0)
);
GO

CREATE NONCLUSTERED INDEX IX_Productos_CategoriaId ON dbo.Productos (CategoriaId);
CREATE NONCLUSTERED INDEX IX_Productos_ProveedorId ON dbo.Productos (ProveedorId);
GO

CREATE TABLE dbo.Ventas (
    VentaId        INT IDENTITY(1,1) NOT NULL,
    NumeroBoleta   NVARCHAR(20)      NOT NULL,
    FechaVenta     DATETIME2(7)      NOT NULL CONSTRAINT DF_Ventas_FechaVenta DEFAULT (GETDATE()),
    ClienteNombre  NVARCHAR(100)     NOT NULL CONSTRAINT DF_Ventas_ClienteNombre DEFAULT ('Público General'),
    MetodoPago     NVARCHAR(30)      NOT NULL CONSTRAINT DF_Ventas_MetodoPago DEFAULT ('Efectivo'),
    Total          DECIMAL(10,2)     NOT NULL CONSTRAINT DF_Ventas_Total DEFAULT (0.00),
    Estado         NVARCHAR(20)      NOT NULL CONSTRAINT DF_Ventas_Estado DEFAULT ('Completada'),
    CONSTRAINT PK_Ventas PRIMARY KEY CLUSTERED (VentaId),
    CONSTRAINT UQ_Ventas_NumeroBoleta UNIQUE (NumeroBoleta),
    CONSTRAINT CK_Ventas_Total CHECK (Total >= 0)
);
GO

CREATE NONCLUSTERED INDEX IX_Ventas_FechaVenta ON dbo.Ventas (FechaVenta DESC);
GO

CREATE TABLE dbo.DetalleVentas (
    DetalleId      INT IDENTITY(1,1) NOT NULL,
    VentaId        INT               NOT NULL,
    ProductoId     INT               NOT NULL,
    Cantidad       INT               NOT NULL,
    PrecioUnitario DECIMAL(10,2)     NOT NULL,
    Subtotal       DECIMAL(10,2)     NOT NULL,
    CONSTRAINT PK_DetalleVentas PRIMARY KEY CLUSTERED (DetalleId),
    CONSTRAINT FK_DetalleVentas_Ventas FOREIGN KEY (VentaId) REFERENCES dbo.Ventas (VentaId) ON DELETE CASCADE,
    CONSTRAINT FK_DetalleVentas_Productos FOREIGN KEY (ProductoId) REFERENCES dbo.Productos (ProductoId),
    CONSTRAINT CK_DetalleVentas_Cantidad CHECK (Cantidad > 0),
    CONSTRAINT CK_DetalleVentas_PrecioUnitario CHECK (PrecioUnitario >= 0),
    CONSTRAINT CK_DetalleVentas_Subtotal CHECK (Subtotal >= 0)
);
GO

CREATE NONCLUSTERED INDEX IX_DetalleVentas_VentaId ON dbo.DetalleVentas (VentaId);
CREATE NONCLUSTERED INDEX IX_DetalleVentas_ProductoId ON dbo.DetalleVentas (ProductoId);
GO

-- 3. DML - INSERCIÓN DE DATOS SEMILLA
SET NOCOUNT ON;

INSERT INTO dbo.Categorias (Nombre, Descripcion, Activo) VALUES
(N'Bebidas y Refrescos',   N'Aguas, gaseosas, néctares e hidratantes', 1),
(N'Lácteos y Derivados',   N'Leche evaporada, quesos, mantequillas y yogures', 1),
(N'Abarrotes y Granos',    N'Arroz, fideos, azúcar, aceites y conservas', 1),
(N'Snacks y Golosinas',    N'Papas fritas, galletas, chocolates y caramelos', 1),
(N'Cuidado del Hogar',     N'Detergentes, jabones, lavavajillas y lejías', 1);

INSERT INTO dbo.Proveedores (Ruc, RazonSocial, Telefono, Email, Direccion, Activo) VALUES
(N'20100055237', N'ALICORP S.A.A.',              N'01-315-0000', N'ventas@alicorp.com.pe',        N'Av. Argentina 4793, Callao', 1),
(N'20100190797', N'LECHE GLORIA S.A.',           N'01-470-7170', N'atencionalcliente@gloria.com', N'Av. República de Panamá 2461, Lima', 1),
(N'20100107563', N'ARCA CONTINENTAL LINDLEY S.A.', N'01-311-5500', N'pedidos@arcacontal.com',       N'Av. Javier Prado Este 6210, La Molina', 1),
(N'20100138957', N'NESTLÉ PERÚ S.A.',            N'01-800-10210', N'contacto@pe.nestle.com',      N'Calle Luis Galvani 493, Lima', 1),
(N'20100113610', N'MONDELEZ PERÚ S.A.',          N'01-614-2200', N'distribucion@mdlz.com',        N'Av. Venezuela 2470, Cercado de Lima', 1);

INSERT INTO dbo.Productos (CodigoBarras, Nombre, CategoriaId, ProveedorId, PrecioCompra, PrecioVenta, Stock, Activo) VALUES
(N'7750106001011', N'Inca Kola 500ml Pet',             1, 3, 2.20, 3.50, 48, 1),
(N'7750106001028', N'Coca Cola 500ml Pet',             1, 3, 2.20, 3.50, 40, 1),
(N'7750106001035', N'Agua San Luis 625ml Sin Gas',     1, 3, 1.10, 2.00, 60, 1),
(N'7750243010018', N'Leche Gloria Azul 400g Lata',     2, 2, 3.40, 4.20, 72, 1),
(N'7750243010025', N'Yogurt Gloria Fresa 1 Litro',      2, 2, 4.80, 6.50, 24, 1),
(N'7750243010032', N'Mantequilla Gloria con Sal 200g', 2, 2, 5.20, 7.00, 18, 1),
(N'7750885002014', N'Arroz Costeño Extra 1kg',         3, 1, 3.80, 4.80, 50, 1),
(N'7750885002021', N'Aceite Primor Clásico 900ml',      3, 1, 6.80, 8.90, 30, 1),
(N'7750885002038', N'Fideos Don Vittorio Spaghetti 450g', 3, 1, 2.10, 3.00, 45, 1),
(N'7750885002045', N'Atún Primor Trozos en Aceite 170g', 3, 1, 4.30, 5.80, 36, 1),
(N'7613035003019', N'Galletas Sublime Chocolate 6 Pack', 4, 4, 3.00, 4.50, 25, 1),
(N'7622210003026', N'Galletas Oreo Regular 108g',      4, 5, 1.80, 2.80, 35, 1),
(N'7613035003033', N'Chocolate Triángulo D’Onofrio 30g', 4, 4, 1.20, 2.00, 50, 1),
(N'7750885005015', N'Detergente Bolívar Floral 900g',  5, 1, 6.50, 8.80, 20, 1),
(N'7750885005022', N'Lavavajillas Sapolio Limón 450g', 5, 1, 3.10, 4.50, 28, 1);

INSERT INTO dbo.Ventas (NumeroBoleta, FechaVenta, ClienteNombre, MetodoPago, Total, Estado) VALUES
(N'B001-00000101', '2026-09-28 08:30:00', N'Carlos Mendoza',   N'Efectivo', 15.50, N'Completada'),
(N'B001-00000102', '2026-09-28 10:15:00', N'María Rodríguez',  N'Yape',     20.20, N'Completada'),
(N'B001-00000103', '2026-09-28 12:45:00', N'Público General',  N'Efectivo',  5.50, N'Completada'),
(N'B001-00000104', '2026-09-28 15:20:00', N'Lucía Fernández',  N'Tarjeta',  26.70, N'Completada');

INSERT INTO dbo.DetalleVentas (VentaId, ProductoId, Cantidad, PrecioUnitario, Subtotal) VALUES
(1, 1, 2, 3.50, 7.00),
(1, 4, 2, 4.25, 8.50),
(2, 8, 1, 8.90, 8.90),
(2, 7, 1, 4.80, 4.80),
(2, 5, 1, 6.50, 6.50),
(3, 2, 1, 3.50, 3.50),
(3, 13, 1, 2.00, 2.00),
(4, 10, 2, 5.80, 11.60),
(4, 14, 1, 8.80, 8.80),
(4, 11, 1, 4.50, 4.50),
(4, 12, 1, 1.80, 1.80);
GO

SELECT 'Categorias' AS Tabla, COUNT(*) AS TotalRegistros FROM dbo.Categorias
UNION ALL
SELECT 'Proveedores', COUNT(*) FROM dbo.Proveedores
UNION ALL
SELECT 'Productos', COUNT(*) FROM dbo.Productos
UNION ALL
SELECT 'Ventas', COUNT(*) FROM dbo.Ventas
UNION ALL
SELECT 'DetalleVentas', COUNT(*) FROM dbo.DetalleVentas;
GO
