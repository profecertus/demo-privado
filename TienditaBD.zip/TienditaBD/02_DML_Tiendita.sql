-- ============================================================================
-- SCRIPT DML: INSERCIÓN DE DATOS DE PRUEBA (SEMILLA) - SISTEMA TIENDITA
-- Entorno objetivo: Microsoft SQL Server (Windows)
-- Base de datos: TienditaDB
-- ============================================================================

USE TienditaDB;
GO

SET NOCOUNT ON;

-- Limpieza controlada en caso de re-ejecución
DELETE FROM dbo.DetalleVentas;
DELETE FROM dbo.Ventas;
DELETE FROM dbo.Productos;
DELETE FROM dbo.Proveedores;
DELETE FROM dbo.Categorias;

-- Reiniciar contadores de identidad
DBCC CHECKIDENT ('dbo.DetalleVentas', RESEED, 0);
DBCC CHECKIDENT ('dbo.Ventas', RESEED, 0);
DBCC CHECKIDENT ('dbo.Productos', RESEED, 0);
DBCC CHECKIDENT ('dbo.Proveedores', RESEED, 0);
DBCC CHECKIDENT ('dbo.Categorias', RESEED, 0);
GO

-- ============================================================================
-- 1. POBLAR TABLA: Categorias (5 categorías maestras)
-- ============================================================================
INSERT INTO dbo.Categorias (Nombre, Descripcion, Activo) VALUES
(N'Bebidas y Refrescos',   N'Aguas, gaseosas, néctares e hidratantes', 1),
(N'Lácteos y Derivados',   N'Leche evaporada, quesos, mantequillas y yogures', 1),
(N'Abarrotes y Granos',    N'Arroz, fideos, azúcar, aceites y conservas', 1),
(N'Snacks y Golosinas',    N'Papas fritas, galletas, chocolates y caramelos', 1),
(N'Cuidado del Hogar',     N'Detergentes, jabones, lavavajillas y lejías', 1);
GO

-- ============================================================================
-- 2. POBLAR TABLA: Proveedores (5 empresas distribuidoras reconocidas)
-- ============================================================================
INSERT INTO dbo.Proveedores (Ruc, RazonSocial, Telefono, Email, Direccion, Activo) VALUES
(N'20100055237', N'ALICORP S.A.A.',              N'01-315-0000', N'ventas@alicorp.com.pe',        N'Av. Argentina 4793, Callao', 1),
(N'20100190797', N'LECHE GLORIA S.A.',           N'01-470-7170', N'atencionalcliente@gloria.com', N'Av. República de Panamá 2461, Lima', 1),
(N'20100107563', N'ARCA CONTINENTAL LINDLEY S.A.', N'01-311-5500', N'pedidos@arcacontal.com',       N'Av. Javier Prado Este 6210, La Molina', 1),
(N'20100138957', N'NESTLÉ PERÚ S.A.',            N'01-800-10210', N'contacto@pe.nestle.com',      N'Calle Luis Galvani 493, Lima', 1),
(N'20100113610', N'MONDELEZ PERÚ S.A.',          N'01-614-2200', N'distribucion@mdlz.com',        N'Av. Venezuela 2470, Cercado de Lima', 1);
GO

-- ============================================================================
-- 3. POBLAR TABLA: Productos (15 productos variados)
-- ============================================================================
-- Nota: CategoriaId y ProveedorId asumen los IDs generados por el IDENTITY correlativo (1 a 5)
INSERT INTO dbo.Productos (CodigoBarras, Nombre, CategoriaId, ProveedorId, PrecioCompra, PrecioVenta, Stock, Activo) VALUES
-- Bebidas (Categoria 1)
(N'7750106001011', N'Inca Kola 500ml Pet',             1, 3, 2.20, 3.50, 48, 1),
(N'7750106001028', N'Coca Cola 500ml Pet',             1, 3, 2.20, 3.50, 40, 1),
(N'7750106001035', N'Agua San Luis 625ml Sin Gas',     1, 3, 1.10, 2.00, 60, 1),

-- Lácteos (Categoria 2)
(N'7750243010018', N'Leche Gloria Azul 400g Lata',     2, 2, 3.40, 4.20, 72, 1),
(N'7750243010025', N'Yogurt Gloria Fresa 1 Litro',      2, 2, 4.80, 6.50, 24, 1),
(N'7750243010032', N'Mantequilla Gloria con Sal 200g', 2, 2, 5.20, 7.00, 18, 1),

-- Abarrotes (Categoria 3)
(N'7750885002014', N'Arroz Costeño Extra 1kg',         3, 1, 3.80, 4.80, 50, 1),
(N'7750885002021', N'Aceite Primor Clásico 900ml',      3, 1, 6.80, 8.90, 30, 1),
(N'7750885002038', N'Fideos Don Vittorio Spaghetti 450g', 3, 1, 2.10, 3.00, 45, 1),
(N'7750885002045', N'Atún Primor Trozos en Aceite 170g', 3, 1, 4.30, 5.80, 36, 1),

-- Snacks y Golosinas (Categoria 4)
(N'7613035003019', N'Galletas Sublime Chocolate 6 Pack', 4, 4, 3.00, 4.50, 25, 1),
(N'7622210003026', N'Galletas Oreo Regular 108g',      4, 5, 1.80, 2.80, 35, 1),
(N'7613035003033', N'Chocolate Triángulo D’Onofrio 30g', 4, 4, 1.20, 2.00, 50, 1),

-- Cuidado del Hogar (Categoria 5)
(N'7750885005015', N'Detergente Bolívar Floral 900g',  5, 1, 6.50, 8.80, 20, 1),
(N'7750885005022', N'Lavavajillas Sapolio Limón 450g', 5, 1, 3.10, 4.50, 28, 1);
GO

-- ============================================================================
-- 4. POBLAR TABLA: Ventas (4 ventas representativas)
-- ============================================================================
INSERT INTO dbo.Ventas (NumeroBoleta, FechaVenta, ClienteNombre, MetodoPago, Total, Estado) VALUES
(N'B001-00000101', '2026-09-28 08:30:00', N'Carlos Mendoza',   N'Efectivo', 15.50, N'Completada'),
(N'B001-00000102', '2026-09-28 10:15:00', N'María Rodríguez',  N'Yape',     20.20, N'Completada'),
(N'B001-00000103', '2026-09-28 12:45:00', N'Público General',  N'Efectivo',  5.50, N'Completada'),
(N'B001-00000104', '2026-09-28 15:20:00', N'Lucía Fernández',  N'Tarjeta',  26.70, N'Completada');
GO

-- ============================================================================
-- 5. POBLAR TABLA: DetalleVentas (Artículos asociados a cada venta)
-- ============================================================================
-- Venta 1 (Total: 15.50) -> 2x Inca Kola (7.00) + 2x Leche Gloria (8.40 approx -> ajuste 2x3.50 + 2x4.25... ver detalle):
INSERT INTO dbo.DetalleVentas (VentaId, ProductoId, Cantidad, PrecioUnitario, Subtotal) VALUES
(1, 1, 2, 3.50, 7.00),   -- 2 x Inca Kola 500ml = 7.00
(1, 4, 2, 4.25, 8.50);   -- 2 x Leche Gloria = 8.50 -> Total: 15.50

-- Venta 2 (Total: 20.20) -> 1x Aceite Primor (8.90) + 1x Arroz Costeño (4.80) + 1x Yogurt Gloria (6.50) = 20.20
INSERT INTO dbo.DetalleVentas (VentaId, ProductoId, Cantidad, PrecioUnitario, Subtotal) VALUES
(2, 8, 1, 8.90, 8.90),   -- 1 x Aceite Primor
(2, 7, 1, 4.80, 4.80),   -- 1 x Arroz Costeño
(2, 5, 1, 6.50, 6.50);   -- 1 x Yogurt Gloria

-- Venta 3 (Total: 5.50) -> 1x Coca Cola (3.50) + 1x Chocolate Triángulo (2.00) = 5.50
INSERT INTO dbo.DetalleVentas (VentaId, ProductoId, Cantidad, PrecioUnitario, Subtotal) VALUES
(3, 2, 1, 3.50, 3.50),   -- 1 x Coca Cola
(3, 13, 1, 2.00, 2.00);  -- 1 x Triángulo D'Onofrio

-- Venta 4 (Total: 26.70) -> 2x Atún Primor (11.60) + 1x Detergente Bolívar (8.80) + 1x Galletas Sublime (4.50) + 1x Oreo (1.80):
INSERT INTO dbo.DetalleVentas (VentaId, ProductoId, Cantidad, PrecioUnitario, Subtotal) VALUES
(4, 10, 2, 5.80, 11.60), -- 2 x Atún Primor (11.60)
(4, 14, 1, 8.80, 8.80),  -- 1 x Detergente Bolívar (8.80)
(4, 11, 1, 4.50, 4.50),  -- 1 x Sublime 6 Pack (4.50)
(4, 12, 1, 1.80, 1.80);  -- 1 x Galleta Oreo (1.80) -> Total: 26.70
GO

-- ============================================================================
-- VERIFICACIÓN RÁPIDA
-- ============================================================================
SELECT 'Categorias' AS Tabla, COUNT(*) AS TotalRegistros FROM dbo.Categorias
UNION ALL
SELECT 'Proveedores', COUNT(*) FROM dbo.Proveedores
UNION ALL
SELECT 'Productos', COUNT(*) FROM dbo.Productos
UNION ALL
SELECT 'Ventas', COUNT(*) FROM dbo.Ventas
UNION ALL
SELECT 'DetalleVentas', COUNT(*) FROM dbo.DetalleVentas;
GO
