# TienditaDB - Base de Datos para Práctica Entity Framework Core (Database-First)

Este directorio contiene los scripts SQL preparados para Microsoft SQL Server en entorno Windows.

## 📁 Archivos incluidos

1. `01_DDL_Tiendita.sql`: Creación de la base de datos `TienditaDB`, esquemas, tablas con claves primarias, claves foráneas, restricciones `CHECK`, valores `DEFAULT` e índices `NONCLUSTERED`.
2. `02_DML_Tiendita.sql`: Inserción de datos maestros y transaccionales representativos (5 categorías, 5 proveedores, 15 productos, 4 ventas y 11 detalles de venta).
3. `Tiendita_Completo.sql`: Script unificado (DDL + DML) para ejecutar de principio a fin en una sola operación.

## 📊 Modelo Relacional (5 Tablas)

- **Categorias** (1) ───< (N) **Productos**
- **Proveedores** (1) ───< (N) **Productos**
- **Ventas** (1) ───< (N) **DetalleVentas**
- **Productos** (1) ───< (N) **DetalleVentas**

## 💻 Instrucciones de Ejecución en Windows

### Opción A: Mediante SQL Server Management Studio (SSMS)
1. Abrir **SSMS** y conectarse a la instancia local (`.` o `localhost` o `.\SQLEXPRESS`).
2. Abrir el archivo `Tiendita_Completo.sql` (`Archivo > Abrir > Archivo...` o `Ctrl + O`).
3. Presionar **F5** o hacer clic en **Ejecutar**.

### Opción B: Mediante Windows PowerShell / CMD (`sqlcmd`)
```powershell
sqlcmd -S localhost\SQLEXPRESS -E -i Tiendita_Completo.sql
```
*(Si usas la instancia por defecto de SQL Server Developer/Enterprise, usa `-S localhost` o `-S .`)*
